<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TourGuide extends Model
{
    protected $table = "tbl_tourguides";
    protected $primaryKey = "id_tourguide";
}
