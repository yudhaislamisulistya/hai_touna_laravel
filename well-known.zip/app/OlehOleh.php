<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OlehOleh extends Model
{
    protected $table = "tbl_oleholeh";
    protected $primaryKey = "id_oleholeh";
}
