<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Komunitas extends Model
{
    protected $table = "tbl_komunitas";
    protected $primaryKey = "id_komunitas";
}
