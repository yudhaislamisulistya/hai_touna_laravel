<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Budaya extends Model
{
    protected $table = "tbl_budayas";
    protected $primaryKey = "id_budaya";
}
