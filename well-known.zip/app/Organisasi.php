<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Organisasi extends Model
{
    protected $table = "tbl_organisasis";
    protected $primaryKey = "id_organisasi";
}
