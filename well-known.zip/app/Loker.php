<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Loker extends Model
{
    protected $table = "tbl_lokers";
    protected $primaryKey = "id_loker";
}
