<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Kuliner extends Model
{
    protected $table = "tbl_kuliners";
    protected $primaryKey = "id_kuliner";
}
