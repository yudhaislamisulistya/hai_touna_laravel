<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Wisata extends Model
{
    protected $table = "tbl_wisatas";
    protected $primaryKey = "id_wisata";
}
